var searchData=
[
  ['context_20manipulation_20api',['Context manipulation API',['../group__CONTEXT__API.html',1,'']]],
  ['command_20line_20switches',['Command Line Switches',['../group__KNOBS.html',1,'']]],
  ['controlling_20and_20initializing',['Controlling and Initializing',['../group__PIN__CONTROL.html',1,'']]]
];
