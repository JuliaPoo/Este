var searchData=
[
  ['reg',['REG',['../group__REG__CPU__IA32.html#ga0f57fb50e80d686a588694f73046f2aa',1,'LEVEL_BASE']]],
  ['reg_5faccess',['REG_ACCESS',['../group__REG__CPU__IA32.html#ga9df40496bf2f29c7a2c5980be42dcb78',1,'LEVEL_BASE']]],
  ['reg_5falloc_5ftype',['REG_ALLOC_TYPE',['../group__REG__CPU__IA32.html#ga2b1cf2faaa7fa5341a7b8ea382a0fadd',1,'LEVEL_BASE']]],
  ['reg_5fclass',['REG_CLASS',['../group__REG__CPU__IA32.html#ga99beb1f4b1dd69c64e5aff9591f7eb24',1,'LEVEL_BASE']]],
  ['reg_5fsubclass',['REG_SUBCLASS',['../group__REG__CPU__IA32.html#gac3fde05e1d7397e8e525ac3f60872406',1,'LEVEL_BASE']]],
  ['regname',['REGNAME',['../group__REG__CPU__IA32.html#gacc81a8433e2f250fc341758e21611be6',1,'LEVEL_BASE']]],
  ['regwidth',['REGWIDTH',['../group__REG__CPU__IA32.html#ga92c4a19fb1078e9a7d9a54b42d3118e7',1,'LEVEL_BASE']]]
];
