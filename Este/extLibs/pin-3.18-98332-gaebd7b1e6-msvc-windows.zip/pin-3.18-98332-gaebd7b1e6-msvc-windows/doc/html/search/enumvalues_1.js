var searchData=
[
  ['call_5forder_5fdefault',['CALL_ORDER_DEFAULT',['../group__INST__ARGS.html#gga3d1d5f6805cb16d00bce441290ca2212a43af3c7aa24c81dddf629b2828b8354c',1,'types_vmapi.H']]],
  ['call_5forder_5ffirst',['CALL_ORDER_FIRST',['../group__INST__ARGS.html#gga3d1d5f6805cb16d00bce441290ca2212a3f53c3878be5c2859b82b540561b72b3',1,'types_vmapi.H']]],
  ['call_5forder_5flast',['CALL_ORDER_LAST',['../group__INST__ARGS.html#gga3d1d5f6805cb16d00bce441290ca2212a0b197a15a2399e6443ce6be187ccf6c6',1,'types_vmapi.H']]],
  ['context_5fchange_5freason_5fapc',['CONTEXT_CHANGE_REASON_APC',['../group__PIN__CONTROL.html#gga8e4e6511a0e09fdc5ec7d6dbf395b3a8a641c250ce491d66cc19f1205160dc279',1,'types_vmapi.H']]],
  ['context_5fchange_5freason_5fcallback',['CONTEXT_CHANGE_REASON_CALLBACK',['../group__PIN__CONTROL.html#gga8e4e6511a0e09fdc5ec7d6dbf395b3a8a5b48097c22e4fcfdf12650129f364b50',1,'types_vmapi.H']]],
  ['context_5fchange_5freason_5fexception',['CONTEXT_CHANGE_REASON_EXCEPTION',['../group__PIN__CONTROL.html#gga8e4e6511a0e09fdc5ec7d6dbf395b3a8ae4c034a98f8eba91b2f8ac5b2543492b',1,'types_vmapi.H']]],
  ['context_5fchange_5freason_5ffatalsignal',['CONTEXT_CHANGE_REASON_FATALSIGNAL',['../group__PIN__CONTROL.html#gga8e4e6511a0e09fdc5ec7d6dbf395b3a8ae712c798df1d0e94022f6382a4c8239e',1,'types_vmapi.H']]],
  ['context_5fchange_5freason_5fsignal',['CONTEXT_CHANGE_REASON_SIGNAL',['../group__PIN__CONTROL.html#gga8e4e6511a0e09fdc5ec7d6dbf395b3a8a43b8b032e969e0e5d14a3ed7385f29db',1,'types_vmapi.H']]],
  ['context_5fchange_5freason_5fsigreturn',['CONTEXT_CHANGE_REASON_SIGRETURN',['../group__PIN__CONTROL.html#gga8e4e6511a0e09fdc5ec7d6dbf395b3a8a7e8b6943c9aa3a85b0a9cd23bc738dd9',1,'types_vmapi.H']]]
];
