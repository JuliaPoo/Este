var searchData=
[
  ['debug_5fconnection_5ftype',['DEBUG_CONNECTION_TYPE',['../group__APPDEBUG__API.html#ga25f41d731fbc522fea67abd02f9c04c6',1,'types_vmapi.H']]],
  ['debug_5fmode_5foption',['DEBUG_MODE_OPTION',['../group__APPDEBUG__API.html#gaf8cf023622aae11218cc9c911b906deb',1,'types_vmapi.H']]],
  ['debug_5fstatus',['DEBUG_STATUS',['../group__APPDEBUG__API.html#ga41e814fff526e0232f2f8c3055d6e88b',1,'types_vmapi.H']]],
  ['debugger_5ftype',['DEBUGGER_TYPE',['../group__APPDEBUG__API.html#ga87ad53f06ecf9cbcd3b94a155e1c11b5',1,'types_vmapi.H']]]
];
