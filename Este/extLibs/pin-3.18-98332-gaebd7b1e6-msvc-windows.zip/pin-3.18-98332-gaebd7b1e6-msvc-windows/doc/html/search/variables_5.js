var searchData=
[
  ['reg_5ffirstinregset',['REG_FirstInRegset',['../group__REG__CPU__IA32.html#ga26dd40b6ba879b7d780b6bbe7f5be172',1,'LEVEL_CORE']]],
  ['reg_5flastinregset',['REG_LastInRegset',['../group__REG__CPU__IA32.html#ga6db162087e0c97051fa5ef6202681d9f',1,'LEVEL_CORE']]],
  ['regcbit_5fall_5fregs',['REGCBIT_ALL_REGS',['../group__REG__CPU__IA32.html#gadfeec7c461b57e3ec949983966fd14bd',1,'LEVEL_BASE']]],
  ['regcbit_5fapp_5fall',['REGCBIT_APP_ALL',['../group__REG__CPU__IA32.html#ga39c70ad3b0ca348c2dfe559b9cc5d568',1,'LEVEL_BASE']]],
  ['regcbit_5fapp_5fflags',['REGCBIT_APP_FLAGS',['../group__REG__CPU__IA32.html#ga59f1010cae5f8d1a7ea1e1b27e471292',1,'LEVEL_BASE']]],
  ['regcbit_5fpartial',['REGCBIT_PARTIAL',['../group__REG__CPU__IA32.html#ga815f23f38997e7a5c768733e538f7e17',1,'LEVEL_BASE']]],
  ['regcbit_5fpin_5fall',['REGCBIT_PIN_ALL',['../group__REG__CPU__IA32.html#gaf7287de7f70ef51c96023b0f6f6ef19f',1,'LEVEL_BASE']]],
  ['regcbit_5fpin_5fflags',['REGCBIT_PIN_FLAGS',['../group__REG__CPU__IA32.html#gad98d3c5262f66a6647e7fb5664572d16',1,'LEVEL_BASE']]],
  ['regsbit_5fpin_5finst_5fall',['REGSBIT_PIN_INST_ALL',['../group__REG__CPU__IA32.html#gad09b267b8bcdc8c88b1523fc5459e69a',1,'LEVEL_BASE']]],
  ['regsbit_5fpin_5fscratch_5fall',['REGSBIT_PIN_SCRATCH_ALL',['../group__REG__CPU__IA32.html#ga412aff7f959c72e2df6ed054feb7c6d0',1,'LEVEL_BASE']]],
  ['regsbit_5fstackptr_5fall',['REGSBIT_STACKPTR_ALL',['../group__REG__CPU__IA32.html#ga6e33cb881e709d00772b9238de121311',1,'LEVEL_BASE']]]
];
