var searchData=
[
  ['sec_3a_20section_20object',['SEC: Section Object',['../group__SEC__BASIC__API.html',1,'']]],
  ['stop_2c_20examine_20and_20resume_20application_20threads_20api',['Stop, examine and resume application threads API',['../group__STOPPED__THREAD__API.html',1,'']]],
  ['sym_3a_20symbol_20object',['SYM: Symbol Object',['../group__SYM__BASIC__API.html',1,'']]]
];
